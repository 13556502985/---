<template>
 <div class="content">
   公告通知
 </div>
</template>

<script>
export default {
 
}
</script>

<style scoped>

</style>
