<template>
    <!-- 根div的class为content确保内容在右边区域出现 -->
    <div class="content">
        在线请假
    </div>
</template>

<script>
export default {
    
}
</script>
<style scoped>
    /* 导入第三方样式或者你写的样式，切记不要在main.js引入，因为可能污染其它组件的样式 */
    /* @import '../../assets/styles/css/yourcss.css'; */

</style>