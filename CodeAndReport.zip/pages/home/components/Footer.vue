<template>
  <div class="footer">
    footer
  </div>
</template>

<script>
  export default {

  }

</script>

<style scoped>
    .footer{
        width:85%;
        height:60px;
        background: #fff;
        position: fixed;
        right: 0;
        bottom: 0;
        box-shadow:0px -2px 10px rgba(0, 0, 0, 0.06);
    }

</style>
