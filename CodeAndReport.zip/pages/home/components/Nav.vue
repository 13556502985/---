<template>
  <div class="nav">
    <h4 class="nav-h4">教务管理系统</h4>
    <div class="side-bar">
      <a-menu mode="inline" theme="dark">
        <template v-for="item in navList">
          <a-menu-item v-if="!item.children" :key="item.key" @click="changeUrl(item.key)">
            <span>{{item.title}}</span>
          </a-menu-item>
          <sub-menu v-else :menu-info="item" :key="item.key"/>
        </template>
      </a-menu>
    </div>
  </div>
</template>

<script>
import SubMenu from "./SubMenu.vue";
export default {
  components: {
    "sub-menu": SubMenu
  },
  data() {
    return {
      navList: [
        {
          key: 'studentLeave',//作为跳转的地址（具有语义的单词拼接）
          title: '在线请假',
        },
        {//一级菜单
          key: 'leaveRecords',
          title: '查看请假记录',
        },
        {//一级菜单
          key: 'changeClassTable',
          title: '修改课表',
        },
        {
          //二级菜单
          key: "attendanceWork",
          title: "考勤工作",
          children: [
            {
              key: "studentAttendance",
              title: "学生考勤"
            },
            {
              key: "teacherAttendance",
              title: "教师考勤"
            }
          ]
        },
        {
          //三级菜单
          key: "approval",
          title: "审批工作",
          children: [
            {
              key: "leaveApproval",
              title: "请假审批",
              children: [
                {
                  key: "studentApproval",
                  title: "学生请假审批"
                },
                {
                  key: "teacherApproval",
                  title: "教师请假审批"
                }
              ]
            },
            {
              key: "classApproval",
              title: "调课补课停课审批"
            }
          ]
        }
      ]
    };
  },
  methods: {
    changeUrl(url) {
      this.$router.push("/home/" + url);
    }
  }
};
</script>

<style scoped>
.nav {
  width: 15%;
  min-width: 120px;
  background: #2c3b48;
  color: rgba(255, 255, 255, 0.8);
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  overflow: hidden;
}

.nav-h4 {
  width: 100%;
  height: 59px;
  min-width: 120px;
  line-height: 59px;
  text-align: center;
  color: #fff;
  font-weight: bold;
  border-bottom: 1px solid #4b545c;
}

.side-bar {
  width: 110%;
  height: 100vh;
  min-width: 120px;
  overflow-y: scroll;
  overflow-x: hidden;
  padding-bottom: 50%;
}

.ant-menu {
  background: #2c3b48 !important;
}
</style>
